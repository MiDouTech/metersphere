# Permissions

Runtime permission is the intersection of:

- MeterSphere user RBAC
- Agent Token scopes
- Project allow-list
- Server-side tool policy

`AGENT_ALL` grants all Agent scopes but never bypasses the bound user's RBAC or project restrictions.
`PROJECT_READ` is required for project search/list/get. During migration, `FUNCTIONAL_READ` / `FUNCTIONAL_ALL` temporarily also grant `PROJECT_READ`.
Empty scopes are denied. Scope matching is exact set membership (no substring match).
