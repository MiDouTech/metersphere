# Platform addresses

Use these built-in platform addresses unless the user explicitly says they are using a private deployment:

- Test environment: `https://msp.ebcone.net`
- Production environment: `https://msp.ebcone.cn`

MCP endpoints:

- Test: `https://msp.ebcone.net/api/mcp`
- Production: `https://msp.ebcone.cn/api/mcp`

Tokens are never embedded in this package. The user must create a personal Agent Token in MeterSphere and configure it as a client secret or environment variable.
