# Troubleshooting

- 401: token missing, expired, disabled, or malformed on POST.
- GET /api/mcp returns 405 (no SSE); clients must use POST Streamable HTTP.
- 403: token scope, user RBAC, or project allow-list does not permit the operation.
- 429 or error.data.code=AGENT_RATE_LIMITED: token rate limit exceeded. Inspect error.data.details.retryAfterMs and nextAction when present. CONFIGURED_WINDOW_UPPER_BOUND is a conservative suggestion, not an exact reset time.
- HTTP 503 with Retry-After: admission is busy. Use bounded backoff and jitter; keep write requestId and payload unchanged. Start with client concurrency 2.
- Preserve traceId for diagnosis; never treat requestId, taskId and traceId as interchangeable.
- VERSION_CONFLICT: reread and compare before changing fields. Unknown failures are not proof that a write did not happen.
- operation.get currently covers the personal execution operations exposed by its live schema; do not assume generic create/query recovery has been implemented.
- Server capabilities, review search/update/disassociation and generic operation-query extensions in implementation plans are not guaranteed live tools. Use tools/list as the authority.
- Do not paste tokens into prompts; configure them as environment variables or client secrets.
