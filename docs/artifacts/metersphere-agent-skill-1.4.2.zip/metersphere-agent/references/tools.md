# Server capabilities

Baseline catalog from the supplied 1.4.1 archive; refresh tools/list against the selected deployment. This offline package is not a runtime capability guarantee. Call tools/list with your token for the authorized subset.

## metersphere.artifact.commit

Scope: ARTIFACT_WRITE

Verify and commit a previously uploaded evidence artifact.

Input schema:
```json
{"properties":{"taskId":{"type":"string"},"executionId":{"type":"string"},"leaseId":{"type":"string"},"leaseToken":{"type":"string"},"artifactId":{"type":"string"},"uploadToken":{"type":"string"},"requestId":{"type":"string"},"traceId":{"type":"string"}},"type":"object","required":["taskId","executionId","leaseId","leaseToken","artifactId","uploadToken","requestId"],"additionalProperties":false}
```

## metersphere.artifact.list

Scope: TASK_READ

List redacted evidence metadata for a PERSONAL_MCP task.

Input schema:
```json
{"properties":{"taskId":{"type":"string"}},"type":"object","required":["taskId"],"additionalProperties":false}
```

## metersphere.artifact.prepare

Scope: ARTIFACT_WRITE

Prepare a bounded evidence upload.

Input schema:
```json
{"properties":{"taskId":{"type":"string"},"executionId":{"type":"string"},"leaseId":{"type":"string"},"leaseToken":{"type":"string"},"caseId":{"type":"string"},"stepId":{"type":"string"},"purpose":{"type":"string"},"fileName":{"type":"string"},"contentType":{"type":"string"},"sizeBytes":{"type":"integer"},"sha256":{"type":"string"},"requestId":{"type":"string"},"traceId":{"type":"string"},"redacted":{"type":"boolean"}},"type":"object","required":["taskId","executionId","leaseId","leaseToken","purpose","fileName","contentType","sizeBytes","sha256","requestId"],"additionalProperties":false}
```

## metersphere.asset.catalog.search

Scope: AI_ASSET_READ

Search published test-asset catalog metadata.

Input schema:
```json
{"properties":{"assetTypes":{"minItems":1,"uniqueItems":true,"type":"array","items":{"enum":["CASE","DOCUMENT","PLAN","DATASET","ENVIRONMENT","PAGE_OBJECT","BUSINESS_FLOW","COMMON_STEP","API_DEFINITION","EVIDENCE","BUG"],"type":"string"},"maxItems":11},"limit":{"maximum":100,"minimum":1,"type":"integer"},"updatedAfter":{"minimum":0,"type":"integer"},"status":{"enum":["PUBLISHED"],"type":"string"},"projectId":{"type":"string"},"cursor":{"type":"string"},"keyword":{"type":"string"}},"type":"object","required":["projectId","assetTypes"],"additionalProperties":false}
```

## metersphere.asset.get

Scope: AI_ASSET_READ

Get test-asset metadata or one immutable version.

Input schema:
```json
{"properties":{"assetId":{"type":"string"},"assetType":{"type":"string"},"versionId":{"type":"string"},"projectId":{"type":"string"}},"type":"object","required":["projectId","assetType","assetId"],"additionalProperties":false}
```

## metersphere.asset.relation.list

Scope: AI_ASSET_READ

List asset relations.

Input schema:
```json
{"properties":{"limit":{"maximum":100,"minimum":1,"type":"integer"},"projectId":{"type":"string"},"cursor":{"type":"string"},"relationType":{"type":"string"},"keyword":{"type":"string"},"assetType":{"type":"string"},"assetId":{"type":"string"}},"type":"object","required":["projectId"],"additionalProperties":false}
```

## metersphere.asset.version.get

Scope: AI_ASSET_READ

Get one immutable asset version.

Input schema:
```json
{"properties":{"projectId":{"type":"string"},"versionId":{"type":"string"}},"type":"object","required":["projectId","versionId"],"additionalProperties":false}
```

## metersphere.bug.attachment.attach

Scope: BUG_ATTACHMENT

Attach uploaded temporary files to a bug.

Input schema:
```json
{"type":"object","properties":{"requestId":{"type":"string","minLength":1,"maxLength":128},"bugId":{"type":"string","minLength":1,"maxLength":128},"attachmentIds":{"type":"array","items":{"type":"string","minLength":1,"maxLength":128},"maxItems":10},"projectId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","bugId","attachmentIds"],"additionalProperties":false}
```

## metersphere.bug.attachment.delete

Scope: BUG_ATTACHMENT

Delete an attachment from a bug.

Input schema:
```json
{"type":"object","properties":{"confirm":{"type":"boolean"},"projectId":{"type":"string","minLength":1,"maxLength":128},"attachmentId":{"type":"string","minLength":1,"maxLength":128},"resourceId":{"type":"string","minLength":1,"maxLength":128},"requestId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","resourceId","attachmentId","confirm"],"additionalProperties":false}
```

## metersphere.bug.attachment.import_url

Scope: BUG_ATTACHMENT

Import public HTTP/HTTPS PNG/JPEG (max 5 MiB) into persistent internal storage. No authenticated/private source. Attach directly to the target attachment area.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"bugId":{"type":"string","minLength":1,"maxLength":128},"url":{"type":"string","minLength":1,"maxLength":8192},"requestId":{"type":"string","minLength":1,"maxLength":128,"pattern":"^[A-Za-z0-9_.:-]{1,128}$"},"fileName":{"type":"string","minLength":1,"maxLength":200}},"required":["projectId","bugId","url","requestId"],"additionalProperties":false}
```

## metersphere.bug.attachment.upload.complete

Scope: BUG_ATTACHMENT

Complete a prepared upload with matching base64 bytes. Returns temporary attachmentId; use attachment.attach or comment.create to associate it. Same uploadId and file replay safely.

Input schema:
```json
{"type":"object","properties":{"contentType":{"type":"string","minLength":1,"maxLength":128},"base64":{"type":"string","minLength":1,"maxLength":6990508},"fileName":{"type":"string","minLength":1,"maxLength":200},"uploadId":{"type":"string","minLength":1,"maxLength":50}},"required":["contentType","base64","fileName","uploadId"],"additionalProperties":false}
```

## metersphere.bug.attachment.upload.prepare

Scope: BUG_ATTACHMENT

Prepare an ordinary bug attachment upload, bound to token/project/purpose/file hash. 5 MiB per file, 15 minute expiry. Does not attach it to the resource.

Input schema:
```json
{"type":"object","properties":{"contentType":{"type":"string","minLength":1,"maxLength":128},"sha256":{"type":"string","minLength":64,"maxLength":64},"projectId":{"type":"string","minLength":1,"maxLength":128},"purpose":{"type":"string","enum":["BUG_DETAIL","BUG_COMMENT"]},"size":{"maximum":5242880,"minimum":1,"type":"integer"},"requestId":{"type":"string","minLength":1,"maxLength":128},"fileName":{"type":"string","minLength":1,"maxLength":200}},"required":["contentType","sha256","projectId","purpose","size","requestId","fileName"],"additionalProperties":false}
```

## metersphere.bug.attachments.list

Scope: BUG_READ

List attachments of a bug.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"bugId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","bugId"],"additionalProperties":false}
```

## metersphere.bug.case.relate

Scope: BUG_RELATE

Relate functional test cases to a bug.

Input schema:
```json
{"type":"object","properties":{"caseIds":{"type":"array","items":{"type":"string","minLength":1,"maxLength":128},"maxItems":100},"projectId":{"type":"string","minLength":1,"maxLength":128},"bugId":{"type":"string","minLength":1,"maxLength":128},"caseType":{"type":"string","enum":["FUNCTIONAL"]},"requestId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","bugId","caseIds"],"additionalProperties":false}
```

## metersphere.bug.case.unrelate

Scope: BUG_RELATE

Unrelate a functional test case from a bug.

Input schema:
```json
{"type":"object","properties":{"requestId":{"type":"string","minLength":1,"maxLength":128},"confirm":{"type":"boolean"},"relationId":{"type":"string","minLength":1,"maxLength":128},"projectId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","relationId","confirm"],"additionalProperties":false}
```

## metersphere.bug.comment.create

Scope: BUG_COMMENT

Create a comment or reply for a bug.

Input schema:
```json
{"type":"object","properties":{"notifier":{"type":"string","minLength":1,"maxLength":2000},"replyUser":{"type":"string","minLength":1,"maxLength":128},"parentId":{"type":"string","minLength":1,"maxLength":128},"bugId":{"type":"string","minLength":1,"maxLength":128},"richTextTmpFileIds":{"type":"array","items":{"type":"string","minLength":1,"maxLength":128},"maxItems":10},"requestId":{"type":"string","minLength":1,"maxLength":128},"event":{"type":"string","enum":["COMMENT","AT","REPLY"]},"content":{"type":"string","minLength":1,"maxLength":20000}},"required":["bugId","content"],"additionalProperties":false}
```

## metersphere.bug.comments.list

Scope: BUG_READ

List comments of a bug.

Input schema:
```json
{"type":"object","properties":{"bugId":{"type":"string","minLength":1,"maxLength":128}},"required":["bugId"],"additionalProperties":false}
```

## metersphere.bug.create

Scope: BUG_WRITE

Create bug

Input schema:
```json
{"properties":{"projectId":{"type":"string"},"title":{"type":"string"},"description":{"type":"string"},"templateId":{"type":"string"},"tags":{"items":{"type":"string"},"type":"array"},"caseId":{"type":"string"},"caseType":{"type":"string"},"testPlanId":{"type":"string"},"testPlanCaseId":{"type":"string"},"customFields":{"additionalProperties":{"type":"string"},"type":"object"},"attachmentIds":{"items":{"type":"string"},"type":"array"},"addCaseIds":{"items":{"type":"string"},"type":"array"},"requestId":{"type":"string"}},"type":"object","required":["projectId","title","requestId"],"additionalProperties":false}
```

## metersphere.bug.export

Scope: BUG_READ

Export 1..100 explicit bugIds as a ZIP containing XLSX. Returns an expiring authenticated downloadPath, size and SHA256 (max 5 MiB). Requires user export permission and BUG_READ.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"requestId":{"type":"string","minLength":1,"maxLength":128},"bugIds":{"minItems":1,"uniqueItems":true,"type":"array","items":{"type":"string","minLength":1,"maxLength":128},"maxItems":100},"exportColumns":{"type":"array","items":{"type":"object","properties":{"columnType":{"enum":["system","custom","other"],"type":"string"},"key":{"type":"string","minLength":1,"maxLength":128}},"required":["key","columnType"],"additionalProperties":false},"minItems":1,"maxItems":50}},"required":["projectId","requestId","bugIds"],"additionalProperties":false}
```

## metersphere.bug.export.columns

Scope: BUG_READ

Read bug export columns; requires current user export permission and BUG_READ.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId"],"additionalProperties":false}
```

## metersphere.bug.get

Scope: BUG_READ

Get bug detail

Input schema:
```json
{"properties":{"bugId":{"type":"string"}},"type":"object","required":["bugId"],"additionalProperties":false}
```

## metersphere.bug.history.list

Scope: BUG_READ

List change history of a bug.

Input schema:
```json
{"type":"object","properties":{"current":{"type":"number"},"pageSize":{"type":"number"},"bugId":{"type":"string","minLength":1,"maxLength":128},"projectId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","bugId"],"additionalProperties":false}
```

## metersphere.bug.import.commit

Scope: BUG_WRITE

Commit a previewed import using unchanged content and previewHash. Each row has its own transaction and persistent idempotency. Returns SUCCEEDED/PARTIAL/FAILED with row results; retries never duplicate successful rows. Requires BUG_WRITE.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"requestId":{"type":"string","minLength":1,"maxLength":128},"templateId":{"type":"string","minLength":1,"maxLength":128},"fileName":{"type":"string","minLength":1,"maxLength":200},"base64":{"type":"string","minLength":1,"maxLength":6990508},"rows":{"type":"array","items":{"type":"object","properties":{"handleUser":{"type":"string","minLength":1,"maxLength":2000},"customFields":{"additionalProperties":{"type":"string"},"type":"object"},"title":{"type":"string","minLength":1,"maxLength":255},"description":{"type":"string","minLength":0,"maxLength":100000}},"required":["title"],"additionalProperties":false},"minItems":1,"maxItems":100},"previewHash":{"type":"string","minLength":64,"maxLength":64}},"required":["projectId","requestId","previewHash"],"additionalProperties":false}
```

## metersphere.bug.import.preview

Scope: BUG_WRITE

Validate rows or a base64 XLSX (exclusive). Headers: title, description, handleUser, custom:<fieldId>. No formulas; max 100 rows/5 MiB. Returns previewHash and per-row errors. Requires BUG_WRITE.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"templateId":{"type":"string","minLength":1,"maxLength":128},"fileName":{"type":"string","minLength":1,"maxLength":200},"base64":{"type":"string","minLength":1,"maxLength":6990508},"rows":{"type":"array","items":{"type":"object","properties":{"handleUser":{"type":"string","minLength":1,"maxLength":2000},"customFields":{"additionalProperties":{"type":"string"},"type":"object"},"title":{"type":"string","minLength":1,"maxLength":255},"description":{"type":"string","minLength":0,"maxLength":100000}},"required":["title"],"additionalProperties":false},"minItems":1,"maxItems":100}},"required":["projectId"],"additionalProperties":false}
```

## metersphere.bug.relate_case

Scope: BUG_RELATE

Relate functional test cases to a bug.

Input schema:
```json
{"type":"object","properties":{"caseIds":{"type":"array","items":{"type":"string","minLength":1,"maxLength":128},"maxItems":100},"projectId":{"type":"string","minLength":1,"maxLength":128},"bugId":{"type":"string","minLength":1,"maxLength":128},"caseType":{"type":"string","enum":["FUNCTIONAL"]},"requestId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","bugId","caseIds"],"additionalProperties":false}
```

## metersphere.bug.search

Scope: BUG_READ

Search bugs

Input schema:
```json
{"properties":{"projectId":{"type":"string"},"query":{"type":"string"},"status":{"items":{"type":"string"},"type":"array"},"handleUserIds":{"items":{"type":"string"},"type":"array"},"current":{"type":"integer","minimum":1},"pageSize":{"type":"integer","minimum":1,"maximum":100}},"type":"object","required":["projectId"],"additionalProperties":false}
```

## metersphere.bug.template.get

Scope: BUG_READ

Get the bug template for a project.

Input schema:
```json
{"type":"object","properties":{"templateId":{"type":"string","minLength":1,"maxLength":128},"projectId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId"],"additionalProperties":false}
```

## metersphere.bug.transition

Scope: BUG_WRITE

Execute an allowed workflow transition using transitionId, targetStatusId and expectedUpdateTime.

Input schema:
```json
{"properties":{"requestId":{"type":"string"},"bugId":{"type":"string"},"transition":{"properties":{"transitionId":{"type":"string"},"targetStatusId":{"type":"string"},"expectedUpdateTime":{"type":"integer"},"comment":{"type":"string"},"override":{"type":"boolean"},"overrideReason":{"type":"string"}},"type":"object","required":["transitionId","targetStatusId","expectedUpdateTime"],"additionalProperties":false},"projectId":{"type":"string"}},"type":"object","required":["projectId","bugId","transition","requestId"],"additionalProperties":false}
```

## metersphere.bug.transitions

Scope: BUG_READ

Get the bug's allowed workflow transitions and current concurrency version.

Input schema:
```json
{"properties":{"projectId":{"type":"string"},"bugId":{"type":"string"}},"type":"object","required":["projectId","bugId"],"additionalProperties":false}
```

## metersphere.bug.update

Scope: BUG_WRITE

Update bug

Input schema:
```json
{"properties":{"projectId":{"type":"string"},"bugId":{"type":"string"},"title":{"type":"string"},"description":{"type":"string"},"tags":{"items":{"type":"string"},"type":"array"},"templateId":{"type":"string"},"customFields":{"additionalProperties":{"type":"string"},"type":"object"},"expectedUpdateTime":{"type":"integer"},"attachmentIds":{"items":{"type":"string"},"type":"array"},"addCaseIds":{"items":{"type":"string"},"type":"array"},"removeRelationIds":{"items":{"type":"string"},"type":"array"},"requestId":{"type":"string"}},"type":"object","required":["projectId","bugId"],"additionalProperties":false}
```

## metersphere.business_flow.get

Scope: AI_ASSET_READ

Get a published governed business flow in the authorized project.

Input schema:
```json
{"properties":{"businessFlowId":{"type":"string"},"projectId":{"type":"string"}},"type":"object","required":["projectId","businessFlowId"],"additionalProperties":false}
```

## metersphere.case_review.associate_cases

Scope: REVIEW_WRITE

Associate cases to review

Input schema:
```json
{"properties":{"requestId":{"type":"string","pattern":"[A-Za-z0-9_.:-]{1,128}"},"projectId":{"type":"string"},"reviewId":{"type":"string"},"caseIds":{"items":{"type":"string"},"type":"array","minItems":0,"maxItems":100},"reviewers":{"items":{"type":"string"},"type":"array","minItems":0,"maxItems":100}},"type":"object","required":["requestId","projectId","reviewId","caseIds"],"additionalProperties":false}
```

## metersphere.case_review.create

Scope: REVIEW_WRITE

Create case review

Input schema:
```json
{"properties":{"requestId":{"type":"string","pattern":"[A-Za-z0-9_.:-]{1,128}"},"projectId":{"type":"string"},"name":{"type":"string","minLength":0,"maxLength":255},"moduleId":{"type":"string"},"reviewPassRule":{"type":"string","pattern":"SINGLE|MULTIPLE"},"reviewers":{"items":{"type":"string"},"type":"array","minItems":0,"maxItems":100},"description":{"type":"string"},"caseIds":{"items":{"type":"string"},"type":"array","minItems":0,"maxItems":100},"tags":{"items":{"type":"string"},"type":"array","minItems":0,"maxItems":100}},"type":"object","required":["requestId","projectId","name"],"additionalProperties":false}
```

## metersphere.case_review.get

Scope: FUNCTIONAL_READ

Get case review detail

Input schema:
```json
{"properties":{"reviewId":{"type":"string"}},"type":"object","required":["reviewId"],"additionalProperties":false}
```

## metersphere.credential.metadata.list

Scope: AI_CREDENTIAL_READ_METADATA

List credential metadata for an environment profile without secretRef or secret value.

Input schema:
```json
{"properties":{"projectId":{"type":"string"},"businessRole":{"type":"string"},"environmentProfileId":{"type":"string"}},"type":"object","required":["projectId","environmentProfileId"],"additionalProperties":false}
```

## metersphere.dataset.metadata.get

Scope: AI_ASSET_READ

Get published dataset metadata without secret data values.

Input schema:
```json
{"properties":{"projectId":{"type":"string"},"datasetId":{"type":"string"}},"type":"object","required":["projectId","datasetId"],"additionalProperties":false}
```

## metersphere.environment.profile.get

Scope: AI_ASSET_READ

Get an executable environment profile in the authorized project.

Input schema:
```json
{"properties":{"environmentProfileId":{"type":"string"},"projectId":{"type":"string"}},"type":"object","required":["projectId","environmentProfileId"],"additionalProperties":false}
```

## metersphere.environment.profile.list

Scope: AI_ASSET_READ

List executable environment profiles.

Input schema:
```json
{"properties":{"projectId":{"type":"string"}},"type":"object","required":["projectId"],"additionalProperties":false}
```

## metersphere.execution.cancel

Scope: AI_EXECUTION_CANCEL

Cancel an AI execution task.

Input schema:
```json
{"properties":{"reason":{"type":"string"},"executionTaskId":{"type":"string"}},"type":"object","required":["executionTaskId"],"additionalProperties":false}
```

## metersphere.execution.checkpoint.create

Scope: TASK_RESULT_WRITE

Persist a hashed execution checkpoint and release the active lease.

Input schema:
```json
{"properties":{"reason":{"type":"string"},"stateSnapshot":{"type":"string"},"executionId":{"type":"string"},"leaseId":{"type":"string"},"taskId":{"type":"string"},"leaseToken":{"type":"string"},"requestId":{"type":"string"}},"type":"object","required":["taskId","leaseId","leaseToken","executionId","reason","stateSnapshot","requestId"],"additionalProperties":false}
```

## metersphere.execution.checkpoint.resume

Scope: AI_EXECUTION_RUN

Resume a personal task checkpoint with its one-time resumeToken and a fresh passed preflightId.

Input schema:
```json
{"properties":{"resumeToken":{"type":"string","maxLength":128,"minLength":40},"taskId":{"type":"string"},"checkpointId":{"type":"string"},"preflightId":{"type":"string"},"requestId":{"type":"string"}},"type":"object","required":["taskId","checkpointId","resumeToken","preflightId","requestId"],"additionalProperties":false}
```

## metersphere.execution.complete

Scope: TASK_RESULT_WRITE

Submit the terminal execution outcome.

Input schema:
```json
{"properties":{"reason":{"type":"string"},"leaseToken":{"type":"string"},"leaseId":{"type":"string"}},"type":"object","required":["leaseId","leaseToken"],"additionalProperties":false}
```

## metersphere.execution.create

Scope: TASK_CLAIM

Create an AI execution task. Backend revalidates project, plan, cases, and confirmation constraints.

Input schema:
```json
{"properties":{"projectId":{"type":"string"},"testPlanId":{"type":"string"},"name":{"type":"string"},"objective":{"type":"string"},"caseIds":{"items":{"type":"string"},"type":"array"},"source":{"type":"string"},"selectionMode":{"type":"string"},"prompt":{"type":"string"},"resolvedFilter":{"type":"string"},"policySnapshot":{"type":"string"},"approvalPolicy":{"type":"string"},"requiredCapabilities":{"items":{"type":"string"},"type":"array"},"assetRefs":{"items":{"properties":{"assetType":{"type":"string"},"assetId":{"type":"string"},"versionId":{"type":"string"}},"type":"object","required":["assetType","assetId"],"additionalProperties":false},"type":"array"},"environmentId":{"type":"string"},"targetUrl":{"type":"string"},"browserType":{"type":"string"},"loginMode":{"type":"string"},"providerId":{"type":"string"},"preflightId":{"type":"string"},"environmentProfileId":{"type":"string"},"credentialReferenceId":{"type":"string"},"modelProfileId":{"type":"string"},"promptTemplateVersionId":{"type":"string"},"runnerId":{"type":"string"},"executionMode":{"type":"string"},"dispatchMode":{"type":"string"},"agentType":{"type":"string"},"executedBy":{"type":"string"},"idempotencyKey":{"type":"string"},"confirmed":{"type":"boolean"},"projectWide":{"type":"boolean"},"timeoutAt":{"type":"integer"},"maxAttempts":{"type":"integer"}},"type":"object","required":["projectId","preflightId"],"additionalProperties":false}
```

## metersphere.execution.events

Scope: AI_EXECUTION_READ

Read append-only AI execution events.

Input schema:
```json
{"properties":{"cursor":{"minimum":0,"type":"integer"},"executionTaskId":{"type":"string"},"limit":{"maximum":500,"minimum":1,"type":"integer"}},"type":"object","required":["executionTaskId"],"additionalProperties":false}
```

## metersphere.execution.events.batch

Scope: TASK_EVENT_WRITE

Append an ordered, idempotent batch of execution events.

Input schema:
```json
{"properties":{"leaseId":{"type":"string"},"events":{"items":{"properties":{"id":{"type":"string"},"contractVersion":{"type":"string"},"eventId":{"type":"string"},"taskId":{"type":"string"},"executionId":{"type":"string"},"leaseId":{"type":"string"},"caseId":{"type":"string"},"stepId":{"type":"string"},"attempt":{"type":"integer"},"sequence":{"type":"integer"},"eventTime":{"type":"integer"},"level":{"type":"string"},"eventType":{"type":"string"},"actorType":{"type":"string"},"actorId":{"type":"string"},"toolName":{"type":"string"},"requestId":{"type":"string"},"traceId":{"type":"string"},"message":{"type":"string"},"artifactIds":{"items":{"type":"string"},"type":"array"},"artifactIdsJson":{"type":"string"},"sanitizedMetadata":{"type":"string"},"payload":{"type":"string"},"createUser":{"type":"string"}},"type":"object","required":[],"additionalProperties":false},"type":"array"},"leaseToken":{"type":"string"}},"type":"object","required":["leaseId","events","leaseToken"],"additionalProperties":false}
```

## metersphere.execution.fail

Scope: TASK_RESULT_WRITE

Submit the terminal execution outcome.

Input schema:
```json
{"properties":{"reason":{"type":"string"},"leaseToken":{"type":"string"},"leaseId":{"type":"string"}},"type":"object","required":["leaseId","leaseToken"],"additionalProperties":false}
```

## metersphere.execution.get

Scope: AI_EXECUTION_READ

Get AI execution task detail.

Input schema:
```json
{"properties":{"executionTaskId":{"type":"string"}},"type":"object","required":["executionTaskId"],"additionalProperties":false}
```

## metersphere.execution.pause

Scope: AI_EXECUTION_RUN

Pause a PERSONAL_MCP execution.

Input schema:
```json
{"properties":{"reason":{"type":"string"},"requestId":{"type":"string"},"executionTaskId":{"type":"string"}},"type":"object","required":["executionTaskId","requestId"],"additionalProperties":false}
```

## metersphere.execution.preflight

Scope: TASK_CLAIM

Validate and freeze scope, environment, credential and policy before creating a PERSONAL_MCP execution.

Input schema:
```json
{"properties":{"testPlanId":{"type":"string"},"requiredCapabilities":{"items":{"type":"string"},"type":"array","maxItems":32},"projectId":{"type":"string"},"environmentProfileId":{"type":"string"},"credentialReferenceId":{"type":"string"},"requestId":{"type":"string"},"runnerType":{"type":"string"},"caseIds":{"items":{"type":"string"},"type":"array","maxItems":100}},"type":"object","required":["projectId","environmentProfileId","runnerType","requestId"],"additionalProperties":false}
```

## metersphere.execution.resolve

Scope: AI_EXECUTION_READ

Resolve project, test plan, and functional case execution scope before creating an AI execution task.

Input schema:
```json
{"properties":{"query":{"type":"string"},"projectId":{"type":"string"},"testPlanId":{"type":"string"},"testPlanName":{"type":"string"},"caseIds":{"items":{"type":"string"},"type":"array"},"caseKeyword":{"type":"string"},"filters":{"properties":{"includeDescendants":{"type":"boolean"},"tagMatch":{"type":"string"},"reviewStatus":{"items":{"type":"string"},"type":"array"},"keyword":{"type":"string"},"priority":{"items":{"type":"string"},"type":"array"},"lastExecuteResult":{"items":{"type":"string"},"type":"array"},"tags":{"items":{"type":"string"},"type":"array"},"moduleIds":{"items":{"type":"string"},"type":"array"},"excludeRiskActions":{"type":"boolean"},"limit":{"type":"integer"}},"type":"object","required":[],"additionalProperties":false},"threshold":{"type":"integer"}},"type":"object","required":[],"additionalProperties":false}
```

## metersphere.execution.result.get

Scope: TASK_READ

Get the current result and verdict for a PERSONAL_MCP task.

Input schema:
```json
{"properties":{"taskId":{"type":"string"}},"type":"object","required":["taskId"],"additionalProperties":false}
```

## metersphere.execution.resume

Scope: AI_EXECUTION_LOGIN

Resume an AI execution task after manual login is ready.

Input schema:
```json
{"properties":{"reason":{"type":"string"},"executionTaskId":{"type":"string"}},"type":"object","required":["executionTaskId"],"additionalProperties":false}
```

## metersphere.execution.retry

Scope: AI_EXECUTION_RUN

Retry a terminal PERSONAL_MCP execution using its frozen scope.

Input schema:
```json
{"properties":{"reason":{"type":"string"},"requestId":{"type":"string"},"executionTaskId":{"type":"string"}},"type":"object","required":["executionTaskId","requestId"],"additionalProperties":false}
```

## metersphere.execution.search

Scope: AI_EXECUTION_READ

Search personal MCP execution history, including terminal tasks. createdAfter/createdBefore are inclusive epoch milliseconds; current/pageSize provide stable newest-first pagination.

Input schema:
```json
{"properties":{"projectId":{"type":"string"},"keyword":{"type":"string","minLength":0,"maxLength":255},"status":{"type":"string","minLength":0,"maxLength":40},"createdAfter":{"type":"integer","minimum":0},"createdBefore":{"type":"integer","minimum":0},"current":{"type":"integer","minimum":1,"maximum":1000000},"pageSize":{"type":"integer","minimum":1,"maximum":100}},"type":"object","required":["projectId","current","pageSize"],"additionalProperties":false}
```

## metersphere.execution.step.result.get

Scope: TASK_READ

Read a persisted step result by requestId after a lost response or expired lease. Requires authorized access to the personal task; never replays a mutation.

Input schema:
```json
{"properties":{"executionId":{"type":"string"},"requestId":{"type":"string"},"taskId":{"type":"string"},"stepId":{"type":"string"}},"type":"object","required":["taskId","executionId","stepId","requestId"],"additionalProperties":false}
```

## metersphere.execution.step.submit

Scope: TASK_RESULT_WRITE

Submit immutable step facts using the frozen contract: v1 uses ordered actual values; v2 requires unique assertionId and typed actual values (DECIMAL/INTEGER as strings). Never submit expected/operator overrides. Reuse requestId and payload for retries; changed payloads conflict.

Input schema:
```json
{"properties":{"taskId":{"type":"string"},"executionId":{"type":"string"},"leaseId":{"type":"string"},"leaseToken":{"type":"string"},"stepId":{"type":"string"},"attempt":{"type":"integer"},"status":{"type":"string"},"inputSnapshot":{"type":"string"},"outputSummary":{"type":"string"},"assertionResult":{"type":"string"},"errorCode":{"type":"string"},"errorMessage":{"type":"string"},"artifactIds":{"items":{"type":"string"},"type":"array"},"requestId":{"type":"string"},"traceId":{"type":"string"},"startedAt":{"type":"integer"},"finishedAt":{"type":"integer"}},"type":"object","required":["taskId","executionId","leaseId","leaseToken","stepId","status","requestId"],"additionalProperties":false}
```

## metersphere.functional.archive.data

Scope: ARTIFACT_WRITE

Archive execution facts independently from results: data. TASK uses an ended managed run; SUBMISSION uses an accepted personal submission. Data requires sourceObjectId/reuseConditions/cleanupStatus and current project file-add permission. Sensitive fields are redacted; reported data is not independently verified. Repeat the same archive; never create fake data when none exists.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"archiveId":{"type":"string","minLength":1,"maxLength":128},"records":{"type":"array","items":{"type":"object","properties":{"values":{"additionalProperties":true,"type":"object"},"cleanupStatus":{"type":"string","minLength":1,"maxLength":2000},"sourceObjectId":{"type":"string","minLength":1,"maxLength":2000},"reuseConditions":{"type":"string","minLength":1,"maxLength":2000}},"required":["sourceObjectId","reuseConditions","cleanupStatus","values"],"additionalProperties":false},"minItems":1,"maxItems":500}},"required":["projectId","archiveId","records"],"additionalProperties":false}
```

## metersphere.functional.archive.get

Scope: ARTIFACT_WRITE

Archive execution facts independently from results: get. TASK uses an ended managed run; SUBMISSION uses an accepted personal submission. Data requires sourceObjectId/reuseConditions/cleanupStatus and current project file-add permission. Sensitive fields are redacted; reported data is not independently verified. Repeat the same archive; never create fake data when none exists.

Input schema:
```json
{"type":"object","properties":{"archiveId":{"type":"string","minLength":1,"maxLength":128},"projectId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","archiveId"],"additionalProperties":false}
```

## metersphere.functional.archive.prepare

Scope: ARTIFACT_WRITE

Archive execution facts independently from results: prepare. TASK uses an ended managed run; SUBMISSION uses an accepted personal submission. Data requires sourceObjectId/reuseConditions/cleanupStatus and current project file-add permission. Sensitive fields are redacted; reported data is not independently verified. Repeat the same archive; never create fake data when none exists.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"sourceType":{"type":"string","enum":["TASK","SUBMISSION"]},"sourceId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","sourceType","sourceId"],"additionalProperties":false}
```

## metersphere.functional.archive.retry

Scope: ARTIFACT_WRITE

Archive execution facts independently from results: retry. TASK uses an ended managed run; SUBMISSION uses an accepted personal submission. Data requires sourceObjectId/reuseConditions/cleanupStatus and current project file-add permission. Sensitive fields are redacted; reported data is not independently verified. Repeat the same archive; never create fake data when none exists.

Input schema:
```json
{"type":"object","properties":{"archiveId":{"type":"string","minLength":1,"maxLength":128},"projectId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","archiveId"],"additionalProperties":false}
```

## metersphere.functional.attachment.attach

Scope: CASE_ATTACHMENT

Attach uploaded temporary files to a functional test case.

Input schema:
```json
{"type":"object","properties":{"caseId":{"type":"string","minLength":1,"maxLength":128},"requestId":{"type":"string","minLength":1,"maxLength":128},"attachmentIds":{"type":"array","items":{"type":"string","minLength":1,"maxLength":128},"maxItems":10},"projectId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","caseId","attachmentIds"],"additionalProperties":false}
```

## metersphere.functional.attachment.delete

Scope: CASE_ATTACHMENT

Delete an attachment from a functional test case.

Input schema:
```json
{"type":"object","properties":{"confirm":{"type":"boolean"},"projectId":{"type":"string","minLength":1,"maxLength":128},"attachmentId":{"type":"string","minLength":1,"maxLength":128},"resourceId":{"type":"string","minLength":1,"maxLength":128},"requestId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","resourceId","attachmentId","confirm"],"additionalProperties":false}
```

## metersphere.functional.attachment.import_url

Scope: CASE_ATTACHMENT

Import public HTTP/HTTPS PNG/JPEG (max 5 MiB) into persistent internal storage. No authenticated/private source. Attach directly to the target attachment area.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"caseId":{"type":"string","minLength":1,"maxLength":128},"url":{"type":"string","minLength":1,"maxLength":8192},"requestId":{"type":"string","minLength":1,"maxLength":128,"pattern":"^[A-Za-z0-9_.:-]{1,128}$"},"fileName":{"type":"string","minLength":1,"maxLength":200}},"required":["projectId","caseId","url","requestId"],"additionalProperties":false}
```

## metersphere.functional.attachment.read

Scope: FUNCTIONAL_READ

Read an authorized published PNG/JPEG attachment as MCP image content, max 5 MiB. Optional submissionId reads retained historical evidence.

Input schema:
```json
{"type":"object","properties":{"caseId":{"type":"string","minLength":1,"maxLength":128},"submissionId":{"type":"string","minLength":1,"maxLength":64},"fileId":{"type":"string","minLength":1,"maxLength":64},"projectId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","caseId","fileId"],"additionalProperties":false}
```

## metersphere.functional.attachment.upload.complete

Scope: CASE_ATTACHMENT

Complete a prepared upload with matching base64 bytes. Returns temporary attachmentId; use attachment.attach or comment.create to associate it. Same uploadId and file replay safely.

Input schema:
```json
{"type":"object","properties":{"contentType":{"type":"string","minLength":1,"maxLength":128},"base64":{"type":"string","minLength":1,"maxLength":6990508},"fileName":{"type":"string","minLength":1,"maxLength":200},"uploadId":{"type":"string","minLength":1,"maxLength":50}},"required":["contentType","base64","fileName","uploadId"],"additionalProperties":false}
```

## metersphere.functional.attachment.upload.prepare

Scope: CASE_ATTACHMENT

Prepare an ordinary case attachment upload, bound to token/project/purpose/file hash. 5 MiB per file, 15 minute expiry. Does not attach it to the resource.

Input schema:
```json
{"type":"object","properties":{"contentType":{"type":"string","minLength":1,"maxLength":128},"sha256":{"type":"string","minLength":64,"maxLength":64},"projectId":{"type":"string","minLength":1,"maxLength":128},"purpose":{"type":"string","enum":["CASE_DETAIL","CASE_COMMENT"]},"size":{"maximum":5242880,"minimum":1,"type":"integer"},"requestId":{"type":"string","minLength":1,"maxLength":128},"fileName":{"type":"string","minLength":1,"maxLength":200}},"required":["contentType","sha256","projectId","purpose","size","requestId","fileName"],"additionalProperties":false}
```

## metersphere.functional.attachments.list

Scope: FUNCTIONAL_READ

List attachments of a functional test case.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"caseId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","caseId"],"additionalProperties":false}
```

## metersphere.functional.case.batch_create

Scope: CASE_WRITE

Batch create functional cases. projectId accepts internal project id, UI project number, or exact project name.

Input schema:
```json
{"properties":{"projectId":{"type":"string"},"moduleId":{"type":"string"},"modulePath":{"type":"string"},"templateId":{"type":"string"},"cases":{"items":{"properties":{"name":{"type":"string","minLength":1,"maxLength":255},"priority":{"type":"string"},"tags":{"items":{"type":"string"},"type":"array"},"prerequisite":{"type":"string"},"description":{"type":"string"},"steps":{"items":{"properties":{"id":{"type":"string"},"num":{"type":"integer"},"desc":{"type":"string"},"expected":{"type":"string"},"actualResult":{"type":"string"},"executeResult":{"type":"string"}},"type":"object","required":[],"additionalProperties":false},"type":"array"}},"type":"object","required":["name"],"additionalProperties":false},"type":"array","minItems":1,"maxItems":100},"failFast":{"type":"boolean"}},"type":"object","required":["projectId","cases"],"additionalProperties":false}
```

## metersphere.functional.case.batch_delete

Scope: CASE_DELETE_V2

Versioned case lifecycle: case.batch_delete. Deletion requires a short-lived preview and the owner's explicit decision in confirmationPath; never substitute confirm=true. CURRENT is default; ALL is explicit. Restore never restarts tasks. New delete/restore scopes are not implied by AGENT_ALL.

Input schema:
```json
{"type":"object","properties":{"previewId":{"type":"string","minLength":1,"maxLength":128}},"required":["previewId"],"additionalProperties":false}
```

## metersphere.functional.case.create

Scope: CASE_WRITE

Create functional case. projectId accepts internal project id, UI project number, or exact project name.

Input schema:
```json
{"properties":{"requestId":{"type":"string","minLength":0,"maxLength":128},"projectId":{"type":"string"},"moduleId":{"type":"string"},"modulePath":{"type":"string"},"templateId":{"type":"string"},"name":{"type":"string","minLength":1,"maxLength":255},"priority":{"type":"string"},"tags":{"items":{"type":"string"},"type":"array"},"prerequisite":{"type":"string"},"description":{"type":"string"},"steps":{"items":{"properties":{"id":{"type":"string"},"num":{"type":"integer"},"desc":{"type":"string"},"expected":{"type":"string"},"actualResult":{"type":"string"},"executeResult":{"type":"string"}},"type":"object","required":[],"additionalProperties":false},"type":"array"}},"type":"object","required":["requestId","projectId","name"],"additionalProperties":false}
```

## metersphere.functional.case.delete

Scope: CASE_DELETE_V2

Versioned case lifecycle: case.delete. Deletion requires a short-lived preview and the owner's explicit decision in confirmationPath; never substitute confirm=true. CURRENT is default; ALL is explicit. Restore never restarts tasks. New delete/restore scopes are not implied by AGENT_ALL.

Input schema:
```json
{"type":"object","properties":{"previewId":{"type":"string","minLength":1,"maxLength":128}},"required":["previewId"],"additionalProperties":false}
```

## metersphere.functional.case.delete_preview

Scope: CASE_DELETE_V2

Versioned case lifecycle: case.delete_preview. Deletion requires a short-lived preview and the owner's explicit decision in confirmationPath; never substitute confirm=true. CURRENT is default; ALL is explicit. Restore never restarts tasks. New delete/restore scopes are not implied by AGENT_ALL.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"versionScope":{"type":"string","enum":["CURRENT","ALL"]},"caseIds":{"type":"array","items":{"type":"string","minLength":1,"maxLength":128},"maxItems":100}},"required":["projectId","caseIds"],"additionalProperties":false}
```

## metersphere.functional.case.restore

Scope: CASE_RESTORE_V2

Versioned case lifecycle: case.restore. Deletion requires a short-lived preview and the owner's explicit decision in confirmationPath; never substitute confirm=true. CURRENT is default; ALL is explicit. Restore never restarts tasks. New delete/restore scopes are not implied by AGENT_ALL.

Input schema:
```json
{"type":"object","properties":{"versionScope":{"type":"string","enum":["CURRENT","ALL"]},"caseId":{"type":"string","minLength":1,"maxLength":128},"expectedUpdateTime":{"minimum":0,"type":"integer"},"projectId":{"type":"string","minLength":1,"maxLength":128},"moduleId":{"type":"string","minLength":1,"maxLength":128},"requestId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","caseId","expectedUpdateTime","requestId"],"additionalProperties":false}
```

## metersphere.functional.case.update

Scope: CASE_UPDATE

Update a functional test case with a partial patch.

Input schema:
```json
{"type":"object","properties":{"patch":{"type":"object","additionalProperties":true},"caseId":{"type":"string","minLength":1,"maxLength":128},"expectedUpdateTime":{"type":"number"},"reason":{"type":"string","minLength":1,"maxLength":2000},"projectId":{"type":"string","minLength":1,"maxLength":128},"requestId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","caseId","expectedUpdateTime","patch","requestId"],"additionalProperties":false}
```

## metersphere.functional.comment.create

Scope: CASE_COMMENT

Create a comment or reply. uploadFileIds must contain temporary attachment IDs returned by the Agent upload endpoint, not storage file IDs.

Input schema:
```json
{"type":"object","properties":{"caseId":{"type":"string","minLength":1,"maxLength":128},"parentId":{"type":"string","minLength":1,"maxLength":128},"projectId":{"type":"string","minLength":1,"maxLength":128},"content":{"type":"string","minLength":1,"maxLength":20000},"requestId":{"type":"string","minLength":1,"maxLength":128},"replyUser":{"type":"string","minLength":1,"maxLength":128},"event":{"type":"string","enum":["COMMENT","AT","REPLY"]},"uploadFileIds":{"type":"array","items":{"type":"string","minLength":1,"maxLength":128},"maxItems":10},"notifier":{"type":"string","minLength":1,"maxLength":2000}},"required":["caseId","projectId","content","requestId"],"additionalProperties":false}
```

## metersphere.functional.comment.delete

Scope: CASE_COMMENT_DELETE_V2

Delete a versioned comment into a tombstone while preserving replies. Author or comment moderator only; explicit CASE_COMMENT_DELETE_V2 and requestId required. AGENT_ALL does not include this grant.

Input schema:
```json
{"type":"object","properties":{"commentId":{"type":"string","minLength":1,"maxLength":128},"expectedUpdateTime":{"minimum":0,"type":"integer"},"projectId":{"type":"string","minLength":1,"maxLength":128},"caseId":{"type":"string","minLength":1,"maxLength":128},"requestId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","caseId","commentId","expectedUpdateTime","requestId"],"additionalProperties":false}
```

## metersphere.functional.comment.update

Scope: CASE_COMMENT_EDIT_V2

Edit your own comment text using expectedUpdateTime. Preserves replies, recipients and attachments; does not resend notifications. Explicit CASE_COMMENT_EDIT_V2 required.

Input schema:
```json
{"type":"object","properties":{"content":{"type":"string","minLength":1,"maxLength":20000},"expectedUpdateTime":{"minimum":0,"type":"integer"},"caseId":{"type":"string","minLength":1,"maxLength":128},"commentId":{"type":"string","minLength":1,"maxLength":128},"projectId":{"type":"string","minLength":1,"maxLength":128},"requestId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","caseId","commentId","content","expectedUpdateTime","requestId"],"additionalProperties":false}
```

## metersphere.functional.comments.list

Scope: FUNCTIONAL_READ

Page case comments (default 10, maximum 100). Returns {list,total,current,pageSize}; roots include the first 10 replies and childTotal. Supply parentId to page replies. Deleted comments are tombstones and retain replies.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"caseId":{"type":"string","minLength":1,"maxLength":128},"pageSize":{"maximum":100,"minimum":1,"type":"integer"},"current":{"maximum":2147483647,"minimum":1,"type":"integer"},"parentId":{"type":"string","minLength":1,"maxLength":128}},"required":["caseId"],"additionalProperties":false}
```

## metersphere.functional.execution.contract

Scope: FUNCTIONAL_READ

Read case steps, contentHash and policyHash for structure-only direct execution. Agent declares SUCCESS/ERROR; actual text is not compared with expected. Cover every original position; extras and repeats are allowed and retained.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"caseId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","caseId"],"additionalProperties":false}
```

## metersphere.functional.execution.evidence.import_url

Scope: FUNCTIONAL_SUBMIT

Import public HTTP/HTTPS PNG/JPEG (max 5 MiB) into persistent internal storage. No authenticated/private source. Stage evidence; visible only after the existing submission gate passes.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"caseId":{"type":"string","minLength":1,"maxLength":128},"url":{"type":"string","minLength":1,"maxLength":8192},"requestId":{"type":"string","minLength":1,"maxLength":128,"pattern":"^[A-Za-z0-9_.:-]{1,128}$"},"contentHash":{"type":"string","minLength":64,"maxLength":64},"stepNum":{"maximum":1000,"minimum":1,"type":"integer"},"purpose":{"enum":["BEFORE_STEP","AFTER_STEP"],"type":"string"},"fileName":{"type":"string","minLength":1,"maxLength":200}},"required":["projectId","caseId","url","requestId"],"additionalProperties":false}
```

## metersphere.functional.execution.evidence.upload

Scope: FUNCTIONAL_SUBMIT

Stage a PNG/JPEG evidence file as base64 (max 5 MiB), at case scope; one image covers all steps; hashes/stepNum/purpose optional. Requires FUNCTIONAL_SUBMIT and CASE_ATTACHMENT. Not visible until gate passes.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"caseId":{"type":"string","minLength":1,"maxLength":128},"requestId":{"type":"string","minLength":1,"maxLength":128,"pattern":"^[A-Za-z0-9_.:-]{1,128}$"},"contentHash":{"type":"string","minLength":64,"maxLength":64},"stepNum":{"maximum":1000,"minimum":1,"type":"integer"},"purpose":{"enum":["BEFORE_STEP","AFTER_STEP"],"type":"string"},"fileName":{"type":"string","minLength":1,"maxLength":200},"contentType":{"enum":["image/png","image/jpeg"],"type":"string"},"base64":{"type":"string","minLength":1,"maxLength":6990508}},"required":["projectId","caseId","requestId","fileName","contentType","base64"],"additionalProperties":false}
```

## metersphere.functional.execution.get

Scope: FUNCTIONAL_READ

Read an authorized direct execution report with step outcomes, evidence mapping and frozen global policy. Sensitive facts are redacted.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"caseId":{"type":"string","minLength":1,"maxLength":128},"submissionId":{"type":"string","minLength":1,"maxLength":64}},"required":["projectId","caseId","submissionId"],"additionalProperties":false}
```

## metersphere.functional.execution.submit

Scope: FUNCTIONAL_SUBMIT

Validate original-step coverage and evidence structure, then publish Agent-reported results. Extra and repeated positions are retained; any ERROR makes the case ERROR. No expected-text comparison or content reviewer. ACCEPTED/PUBLISHED means structure accepted, not independently verified execution. Requires FUNCTIONAL_SUBMIT and CASE_ATTACHMENT.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"caseId":{"type":"string","minLength":1,"maxLength":128},"requestId":{"type":"string","minLength":1,"maxLength":128,"pattern":"^[A-Za-z0-9_.:-]{1,128}$"},"contentHash":{"type":"string","minLength":64,"maxLength":64},"evidenceIds":{"type":"array","items":{"type":"string","minLength":1,"maxLength":64},"minItems":1,"maxItems":10},"policyHash":{"type":"string","minLength":64,"maxLength":64},"steps":{"type":"array","items":{"type":"object","properties":{"stepNum":{"maximum":1000,"minimum":1,"type":"integer"},"evidenceIds":{"type":"array","items":{"type":"string","minLength":1,"maxLength":64},"minItems":0,"maxItems":10},"actual":{"type":"string","minLength":1,"maxLength":20000},"result":{"enum":["SUCCESS","ERROR"],"type":"string"}},"required":["stepNum","actual","result"],"additionalProperties":false},"minItems":1,"maxItems":1000}},"required":["projectId","caseId","requestId","steps"],"additionalProperties":false}
```

## metersphere.functional.export.download

Scope: FUNCTIONAL_READ

Read up to 65536 bytes as base64 at offset, with fresh authorization. Append chunks until eof. Never returns a public file URL.

Input schema:
```json
{"properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"taskId":{"type":"string","minLength":1,"maxLength":64},"offset":{"maximum":67108864,"minimum":0,"type":"integer"},"length":{"maximum":65536,"minimum":1,"type":"integer"}},"type":"object","required":["projectId","taskId"],"additionalProperties":false}
```

## metersphere.functional.export.retry

Scope: FUNCTIONAL_READ

Retry your failed, cancelled or expired export using its original filters and fields against CURRENT case content. Creates a new linked task. Reuse requestId after a lost response.

Input schema:
```json
{"properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"taskId":{"type":"string","minLength":1,"maxLength":64},"requestId":{"maxLength":128,"type":"string","pattern":"^[A-Za-z0-9_.:-]{1,128}$","minLength":1}},"type":"object","required":["projectId","taskId","requestId"],"additionalProperties":false}
```

## metersphere.functional.export.start

Scope: FUNCTIONAL_READ

Create an idempotent Excel/XMind export. request uses web export fields: selectIds/selectAll, moduleIds, systemFields/customFields/otherFields (id/name), isMerge. Poll status, then download chunks.

Input schema:
```json
{"properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"format":{"enum":["xlsx","xmind"],"type":"string"},"requestId":{"maxLength":128,"type":"string","pattern":"^[A-Za-z0-9_.:-]{1,128}$","minLength":1},"request":{"type":"object","properties":{"customFields":{"items":{"type":"object","properties":{"name":{"type":"string","minLength":0,"maxLength":255},"id":{"type":"string","minLength":1,"maxLength":128}},"required":["id"],"additionalProperties":false},"type":"array","maxItems":200},"systemFields":{"items":{"type":"object","properties":{"name":{"type":"string","minLength":0,"maxLength":255},"id":{"type":"string","minLength":1,"maxLength":128}},"required":["id"],"additionalProperties":false},"type":"array","maxItems":200},"otherFields":{"items":{"type":"object","properties":{"name":{"type":"string","minLength":0,"maxLength":255},"id":{"type":"string","minLength":1,"maxLength":128}},"required":["id"],"additionalProperties":false},"type":"array","maxItems":200}},"additionalProperties":true}},"type":"object","required":["projectId","format","requestId","request"],"additionalProperties":false}
```

## metersphere.functional.export.status

Scope: FUNCTIONAL_READ

Read or stop your own durable export task. Stopping a completed task preserves success.

Input schema:
```json
{"properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"taskId":{"type":"string","minLength":1,"maxLength":64}},"type":"object","required":["projectId","taskId"],"additionalProperties":false}
```

## metersphere.functional.export.stop

Scope: FUNCTIONAL_READ

Read or stop your own durable export task. Stopping a completed task preserves success.

Input schema:
```json
{"properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"taskId":{"type":"string","minLength":1,"maxLength":64},"requestId":{"maxLength":128,"type":"string","pattern":"^[A-Za-z0-9_.:-]{1,128}$","minLength":1}},"type":"object","required":["projectId","taskId","requestId"],"additionalProperties":false}
```

## metersphere.functional.get

Scope: FUNCTIONAL_READ

Get functional test case detail

Input schema:
```json
{"properties":{"caseId":{"type":"string"},"testPlanId":{"type":"string"},"includeSteps":{"type":"boolean"}},"type":"object","required":["caseId"],"additionalProperties":false}
```

## metersphere.functional.history.list

Scope: FUNCTIONAL_READ

List change history of a functional test case.

Input schema:
```json
{"type":"object","properties":{"caseId":{"type":"string","minLength":1,"maxLength":128},"current":{"type":"number"},"pageSize":{"type":"number"},"projectId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","caseId"],"additionalProperties":false}
```

## metersphere.functional.import.commit

Scope: CASE_IMPORT_V2

Durable Excel/XMind import: commit. Precheck freezes logical cases, template and overwrite versions (10000 cases/50 MiB, 24h). Commit queues per-case transactions. Get reports every item; retry only pending/failed items, never already committed writes. Explicit CASE_IMPORT_V2 required. Optional commit.followup creates or appends a plan/review pair; PLAN_WRITE and REVIEW_WRITE are additionally required. Missing followup preserves legacy import-only behavior; get reports LEGACY.

Input schema:
```json
{"type":"object","properties":{"jobId":{"type":"string","minLength":1,"maxLength":128},"followup":{"type":"object","properties":{"reviewName":{"type":"string","minLength":1,"maxLength":255},"reviewers":{"type":"array","items":{"type":"string","minLength":1,"maxLength":128},"minItems":1,"maxItems":100},"targetGroupId":{"type":"string","minLength":1,"maxLength":128},"planName":{"type":"string","minLength":1,"maxLength":255},"expectedGroupRevision":{"minimum":1,"type":"integer"},"reviewPassRule":{"enum":["SINGLE","MULTIPLE"],"type":"string"},"policy":{"enum":["CREATE_NEW_PAIR","APPEND_EXISTING","IMPORT_ONLY"],"type":"string"}},"required":["policy"],"additionalProperties":false}},"required":["jobId"],"additionalProperties":false}
```

## metersphere.functional.import.followup.options

Scope: CASE_IMPORT_V2

Durable Excel/XMind import: followup.options. Precheck freezes logical cases, template and overwrite versions (10000 cases/50 MiB, 24h). Commit queues per-case transactions. Get reports every item; retry only pending/failed items, never already committed writes. Explicit CASE_IMPORT_V2 required. Optional commit.followup creates or appends a plan/review pair; PLAN_WRITE and REVIEW_WRITE are additionally required. Missing followup preserves legacy import-only behavior; get reports LEGACY.

Input schema:
```json
{"type":"object","properties":{"jobId":{"type":"string","minLength":1,"maxLength":128}},"required":["jobId"],"additionalProperties":false}
```

## metersphere.functional.import.followup.retry

Scope: CASE_IMPORT_V2

Durable Excel/XMind import: followup.retry. Precheck freezes logical cases, template and overwrite versions (10000 cases/50 MiB, 24h). Commit queues per-case transactions. Get reports every item; retry only pending/failed items, never already committed writes. Explicit CASE_IMPORT_V2 required. Optional commit.followup creates or appends a plan/review pair; PLAN_WRITE and REVIEW_WRITE are additionally required. Missing followup preserves legacy import-only behavior; get reports LEGACY.

Input schema:
```json
{"type":"object","properties":{"jobId":{"type":"string","minLength":1,"maxLength":128}},"required":["jobId"],"additionalProperties":false}
```

## metersphere.functional.import.get

Scope: CASE_IMPORT_V2

Durable Excel/XMind import: get. Precheck freezes logical cases, template and overwrite versions (10000 cases/50 MiB, 24h). Commit queues per-case transactions. Get reports every item; retry only pending/failed items, never already committed writes. Explicit CASE_IMPORT_V2 required. Optional commit.followup creates or appends a plan/review pair; PLAN_WRITE and REVIEW_WRITE are additionally required. Missing followup preserves legacy import-only behavior; get reports LEGACY.

Input schema:
```json
{"type":"object","properties":{"jobId":{"type":"string","minLength":1,"maxLength":128},"pageSize":{"maximum":100,"minimum":1,"type":"integer"},"current":{"minimum":1,"type":"integer"}},"required":["jobId"],"additionalProperties":false}
```

## metersphere.functional.import.precheck

Scope: CASE_IMPORT_V2

Durable Excel/XMind import: precheck. Precheck freezes logical cases, template and overwrite versions (10000 cases/50 MiB, 24h). Commit queues per-case transactions. Get reports every item; retry only pending/failed items, never already committed writes. Explicit CASE_IMPORT_V2 required. Optional commit.followup creates or appends a plan/review pair; PLAN_WRITE and REVIEW_WRITE are additionally required. Missing followup preserves legacy import-only behavior; get reports LEGACY.

Input schema:
```json
{"type":"object","properties":{"base64":{"type":"string","minLength":1,"maxLength":69905068},"versionId":{"type":"string","minLength":1,"maxLength":128},"projectId":{"type":"string","minLength":1,"maxLength":128},"requestId":{"type":"string","minLength":1,"maxLength":128,"pattern":"^[A-Za-z0-9_.:-]{1,128}$"},"moduleId":{"type":"string","minLength":1,"maxLength":128},"fileName":{"type":"string","minLength":1,"maxLength":255},"cover":{"type":"boolean"}},"required":["projectId","fileName","base64","requestId"],"additionalProperties":false}
```

## metersphere.functional.import.retry

Scope: CASE_IMPORT_V2

Durable Excel/XMind import: retry. Precheck freezes logical cases, template and overwrite versions (10000 cases/50 MiB, 24h). Commit queues per-case transactions. Get reports every item; retry only pending/failed items, never already committed writes. Explicit CASE_IMPORT_V2 required. Optional commit.followup creates or appends a plan/review pair; PLAN_WRITE and REVIEW_WRITE are additionally required. Missing followup preserves legacy import-only behavior; get reports LEGACY.

Input schema:
```json
{"type":"object","properties":{"jobId":{"type":"string","minLength":1,"maxLength":128}},"required":["jobId"],"additionalProperties":false}
```

## metersphere.functional.import.stop

Scope: CASE_IMPORT_V2

Durable Excel/XMind import: stop. Precheck freezes logical cases, template and overwrite versions (10000 cases/50 MiB, 24h). Commit queues per-case transactions. Get reports every item; retry only pending/failed items, never already committed writes. Explicit CASE_IMPORT_V2 required. Optional commit.followup creates or appends a plan/review pair; PLAN_WRITE and REVIEW_WRITE are additionally required. Missing followup preserves legacy import-only behavior; get reports LEGACY.

Input schema:
```json
{"type":"object","properties":{"jobId":{"type":"string","minLength":1,"maxLength":128}},"required":["jobId"],"additionalProperties":false}
```

## metersphere.functional.module.create

Scope: CASE_WRITE

Create functional case module. projectId accepts internal project id, UI project number, or exact project name.

Input schema:
```json
{"properties":{"projectId":{"type":"string"},"name":{"type":"string"},"parentId":{"type":"string"},"modulePath":{"type":"string"}},"type":"object","required":["projectId","name"],"additionalProperties":false}
```

## metersphere.functional.module.get

Scope: FUNCTIONAL_READ

Read module metadata and updateTime for concurrency control.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"moduleId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","moduleId"],"additionalProperties":false}
```

## metersphere.functional.module.move

Scope: CASE_MODULE_WRITE_V2

Modify a case module. Explicit CASE_MODULE_WRITE_V2 grant required. parentId=NONE moves to project root; root itself cannot move.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"moduleId":{"type":"string","minLength":1,"maxLength":128},"expectedUpdateTime":{"minimum":0,"type":"integer"},"requestId":{"type":"string","minLength":1,"maxLength":128},"parentId":{"type":"string","minLength":1,"maxLength":255}},"required":["projectId","moduleId","expectedUpdateTime","requestId","parentId"],"additionalProperties":false}
```

## metersphere.functional.module.update

Scope: CASE_MODULE_WRITE_V2

Modify a case module. Explicit CASE_MODULE_WRITE_V2 grant required. parentId=NONE moves to project root; root itself cannot move.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"moduleId":{"type":"string","minLength":1,"maxLength":128},"expectedUpdateTime":{"minimum":0,"type":"integer"},"requestId":{"type":"string","minLength":1,"maxLength":128},"name":{"type":"string","minLength":1,"maxLength":255}},"required":["projectId","moduleId","expectedUpdateTime","requestId","name"],"additionalProperties":false}
```

## metersphere.functional.modules

Scope: FUNCTIONAL_READ

List functional case modules by project. projectId accepts internal project id, UI project number, or exact project name.

Input schema:
```json
{"properties":{"projectId":{"type":"string"}},"type":"object","required":["projectId"],"additionalProperties":false}
```

## metersphere.functional.overview.get

Scope: FUNCTIONAL_READ

Read authorized case overview.get without changing execution results.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"caseId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","caseId"],"additionalProperties":false}
```

## metersphere.functional.search

Scope: FUNCTIONAL_READ

Search functional test cases. Optional projectId accepts internal project id, UI project number, or exact project name; when omitted it uses Agent Token current/default project.

Input schema:
```json
{"properties":{"projectId":{"type":"string"},"identityType":{"type":"string"},"versionId":{"type":"string"},"refId":{"type":"string"},"query":{"type":"string"},"includeSteps":{"type":"boolean"},"testPlanId":{"type":"string"},"filters":{"properties":{"includeDescendants":{"type":"boolean"},"tagMatch":{"type":"string"},"reviewStatus":{"items":{"type":"string"},"type":"array"},"keyword":{"type":"string"},"priority":{"items":{"type":"string"},"type":"array"},"lastExecuteResult":{"items":{"type":"string"},"type":"array"},"tags":{"items":{"type":"string"},"type":"array"},"moduleIds":{"items":{"type":"string"},"type":"array"},"excludeRiskActions":{"type":"boolean"},"limit":{"type":"integer"}},"type":"object","required":[],"additionalProperties":false},"current":{"type":"integer","minimum":1},"pageSize":{"type":"integer","minimum":1,"maximum":100}},"type":"object","required":[],"additionalProperties":false}
```

## metersphere.functional.snapshot.create

Scope: FUNCTIONAL_READ

Freeze a case-library query for complete paged extraction (15 minutes, 10000 cases/50 MiB). Ordinary search remains live. query uses the functional search request fields.

Input schema:
```json
{"type":"object","properties":{"query":{"type":"object","additionalProperties":true}},"required":["query"],"additionalProperties":false}
```

## metersphere.functional.snapshot.page

Scope: FUNCTIONAL_READ

Read frozen case contents. Current authorization and existence are checked; invalid scope requires a new snapshot.

Input schema:
```json
{"type":"object","properties":{"pageSize":{"maximum":100,"minimum":1,"type":"integer"},"snapshotId":{"type":"string","minLength":1,"maxLength":50},"current":{"minimum":1,"type":"integer"}},"required":["snapshotId"],"additionalProperties":false}
```

## metersphere.functional.snapshot.release

Scope: FUNCTIONAL_READ

Release your temporary extraction snapshot; does not delete cases.

Input schema:
```json
{"type":"object","properties":{"snapshotId":{"type":"string","minLength":1,"maxLength":50}},"required":["snapshotId"],"additionalProperties":false}
```

## metersphere.functional.template.get

Scope: FUNCTIONAL_READ

Get the functional case template for a project.

Input schema:
```json
{"type":"object","properties":{"templateId":{"type":"string","minLength":1,"maxLength":128},"projectId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId"],"additionalProperties":false}
```

## metersphere.functional.trash.list

Scope: FUNCTIONAL_READ

Versioned case lifecycle: trash.list. Deletion requires a short-lived preview and the owner's explicit decision in confirmationPath; never substitute confirm=true. CURRENT is default; ALL is explicit. Restore never restarts tasks. New delete/restore scopes are not implied by AGENT_ALL.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"pageSize":{"maximum":100,"minimum":1,"type":"integer"},"current":{"minimum":1,"type":"integer"}},"required":["projectId"],"additionalProperties":false}
```

## metersphere.functional.versions.list

Scope: FUNCTIONAL_READ

Read authorized case versions.list without changing execution results.

Input schema:
```json
{"type":"object","properties":{"projectId":{"type":"string","minLength":1,"maxLength":128},"caseId":{"type":"string","minLength":1,"maxLength":128},"current":{"minimum":1,"type":"integer"},"pageSize":{"maximum":100,"minimum":1,"type":"integer"}},"required":["projectId","caseId"],"additionalProperties":false}
```

## metersphere.human_request.create

Scope: TASK_RESULT_WRITE

Request human approval, input, login or review.

Input schema:
```json
{"properties":{"requestId":{"type":"string","minLength":0,"maxLength":128},"requestType":{"type":"string"},"title":{"type":"string","minLength":0,"maxLength":255},"content":{"type":"string","minLength":0,"maxLength":4000},"riskLevel":{"type":"string"},"expiresAt":{"type":"integer"},"recipientUserIds":{"items":{"type":"string"},"type":"array","minItems":3,"maxItems":3},"checkpointRequired":{"type":"boolean"},"actionHash":{"type":"string"},"taskId":{"type":"string"},"leaseId":{"type":"string"},"leaseToken":{"type":"string"}},"type":"object","required":["requestId","requestType","title","taskId","leaseId","leaseToken"],"additionalProperties":false}
```

## metersphere.human_request.get

Scope: TASK_READ

Read a human intervention request for a task.

Input schema:
```json
{"properties":{"taskId":{"type":"string"},"requestId":{"type":"string"}},"type":"object","required":["taskId","requestId"],"additionalProperties":false}
```

## metersphere.human_request.list

Scope: TASK_READ

List human requests for a PERSONAL_MCP task.

Input schema:
```json
{"properties":{"taskId":{"type":"string"}},"type":"object","required":["taskId"],"additionalProperties":false}
```

## metersphere.human_request.respond

Scope: AI_EXECUTION_LOGIN

Respond as the token owner; first valid recipient wins.

Input schema:
```json
{"properties":{"taskId":{"type":"string"},"response":{"type":"string"},"humanRequestId":{"type":"string"},"action":{"type":"string"},"expectedVersion":{"minimum":0,"type":"integer"},"requestId":{"type":"string"}},"type":"object","required":["taskId","humanRequestId","requestId","action","expectedVersion"],"additionalProperties":false}
```

## metersphere.operation.get

Scope: FUNCTIONAL_READ

Find this Token's personal execution upload/submit result after a lost response. NOT_FOUND is not proof of non-execution: retry only with the original requestId. Requires current case read permission.

Input schema:
```json
{"type":"object","properties":{"caseId":{"type":"string","minLength":1,"maxLength":128},"requestId":{"type":"string","minLength":1,"maxLength":128,"pattern":"^[A-Za-z0-9_.:-]{1,128}$"},"toolName":{"enum":["metersphere.functional.execution.evidence.import_url","metersphere.functional.execution.submit","metersphere.functional.execution.evidence.upload"],"type":"string"},"projectId":{"type":"string","minLength":1,"maxLength":128}},"required":["projectId","caseId","toolName","requestId"],"additionalProperties":false}
```

## metersphere.page_object.get

Scope: AI_ASSET_READ

Get a published governed page object and its semantic locators in the authorized project.

Input schema:
```json
{"properties":{"pageObjectId":{"type":"string"},"projectId":{"type":"string"}},"type":"object","required":["projectId","pageObjectId"],"additionalProperties":false}
```

## metersphere.project.create

Scope: PROJECT_WRITE

Create project

Input schema:
```json
{"properties":{"requestId":{"type":"string","minLength":0,"maxLength":128},"organizationId":{"type":"string"},"name":{"type":"string"},"description":{"type":"string"},"userIds":{"items":{"type":"string"},"type":"array"},"moduleIds":{"items":{"type":"string"},"type":"array"},"resourcePoolIds":{"items":{"type":"string"},"type":"array"},"allResourcePool":{"type":"boolean"}},"type":"object","required":["requestId","organizationId","name","userIds"],"additionalProperties":false}
```

## metersphere.project.get

Scope: PROJECT_READ

Get project detail

Input schema:
```json
{"properties":{"projectId":{"type":"string"}},"type":"object","required":["projectId"],"additionalProperties":false}
```

## metersphere.project.list

Scope: PROJECT_READ

List projects accessible to the current Agent Token user. Same contract as metersphere.project.search.

Input schema:
```json
{"properties":{"limit":{"maximum":200,"minimum":1,"type":"integer"},"page":{"minimum":1,"type":"integer"},"includeArchived":{"type":"boolean"},"pageSize":{"maximum":100,"minimum":1,"type":"integer"},"keyword":{"type":"string"}},"type":"object","required":[],"additionalProperties":false}
```

## metersphere.project.members.add

Scope: PROJECT_WRITE

Add project members

Input schema:
```json
{"properties":{"projectId":{"type":"string"},"userIds":{"items":{"type":"string"},"type":"array"},"userRoleIds":{"items":{"type":"string"},"type":"array"}},"type":"object","required":["projectId","userIds"],"additionalProperties":false}
```

## metersphere.project.search

Scope: PROJECT_READ

Search projects by internal project id, project name, or project number. Supports page/pageSize/includeArchived; returns items/total/hasMore.

Input schema:
```json
{"properties":{"limit":{"maximum":200,"minimum":1,"type":"integer"},"page":{"minimum":1,"type":"integer"},"includeArchived":{"type":"boolean"},"pageSize":{"maximum":100,"minimum":1,"type":"integer"},"keyword":{"type":"string"}},"type":"object","required":[],"additionalProperties":false}
```

## metersphere.task.claim

Scope: TASK_CLAIM

Atomically claim a PERSONAL_MCP task and receive an execution lease.

Input schema:
```json
{"properties":{"taskId":{"type":"string"},"projectId":{"type":"string"},"agentType":{"type":"string"},"capabilities":{"items":{"type":"string"},"type":"array"}},"type":"object","required":["projectId"],"additionalProperties":false}
```

## metersphere.task.get

Scope: TASK_READ

Get a PERSONAL_MCP task and its frozen execution context.

Input schema:
```json
{"properties":{"taskId":{"type":"string"}},"type":"object","required":["taskId"],"additionalProperties":false}
```

## metersphere.task.lease.heartbeat

Scope: TASK_CLAIM

Renew the current execution lease.

Input schema:
```json
{"properties":{"leaseId":{"type":"string"},"leaseToken":{"type":"string"}},"type":"object","required":["leaseId","leaseToken"],"additionalProperties":false}
```

## metersphere.task.release

Scope: TASK_RESULT_WRITE

Release a claimed task and record a safe reason.

Input schema:
```json
{"properties":{"taskId":{"type":"string"},"leaseToken":{"type":"string"},"leaseId":{"type":"string"},"reason":{"type":"string"}},"type":"object","required":["taskId","leaseId","leaseToken"],"additionalProperties":false}
```

## metersphere.task.search

Scope: TASK_READ

Search PERSONAL_MCP tasks visible to the current token.

Input schema:
```json
{"properties":{"taskId":{"type":"string"},"projectId":{"type":"string"},"agentType":{"type":"string"},"capabilities":{"items":{"type":"string"},"type":"array"}},"type":"object","required":["projectId"],"additionalProperties":false}
```

## metersphere.test_plan.associate_cases

Scope: PLAN_WRITE

Associate cases to test plan

Input schema:
```json
{"properties":{"requestId":{"type":"string","pattern":"[A-Za-z0-9_.:-]{1,128}","minLength":1,"maxLength":128},"projectId":{"type":"string"},"testPlanId":{"type":"string"},"caseIds":{"items":{"type":"string"},"type":"array"},"collectionId":{"type":"string"}},"type":"object","required":["requestId","projectId","testPlanId","caseIds"],"additionalProperties":false}
```

## metersphere.test_plan.cases

Scope: FUNCTIONAL_READ

List functional cases in a test plan. Requires projectId and testPlanId.

Input schema:
```json
{"properties":{"includeSteps":{"type":"boolean"},"projectId":{"type":"string"},"testPlanId":{"type":"string"},"pageSize":{"maximum":100,"minimum":1,"type":"integer"},"current":{"minimum":1,"type":"integer"}},"type":"object","required":["projectId","testPlanId"],"additionalProperties":false}
```

## metersphere.test_plan.create

Scope: PLAN_WRITE

Create test plan

Input schema:
```json
{"properties":{"requestId":{"type":"string","pattern":"[A-Za-z0-9_.:-]{1,128}","minLength":1,"maxLength":128},"projectId":{"type":"string"},"name":{"type":"string"},"description":{"type":"string"},"moduleId":{"type":"string"},"caseIds":{"items":{"type":"string"},"type":"array"},"automaticStatusUpdate":{"type":"boolean"},"repeatCase":{"type":"boolean"},"passThreshold":{"type":"number"}},"type":"object","required":["requestId","projectId","name"],"additionalProperties":false}
```

## metersphere.test_plan.disassociate_cases

Scope: PLAN_WRITE

Remove functional-case associations using testPlanCaseId values, not repository caseIds. At most 100; executing or archived plans are rejected.

Input schema:
```json
{"properties":{"requestId":{"type":"string"},"associationIds":{"minItems":1,"uniqueItems":true,"type":"array","items":{"type":"string"},"maxItems":100},"testPlanId":{"type":"string"},"projectId":{"type":"string"}},"type":"object","required":["projectId","testPlanId","associationIds","requestId"],"additionalProperties":false}
```

## metersphere.test_plan.get

Scope: PLAN_READ

Get test plan detail

Input schema:
```json
{"properties":{"testPlanId":{"type":"string"}},"type":"object","required":["testPlanId"],"additionalProperties":false}
```

## metersphere.test_plan.search

Scope: PLAN_READ

Search test plans by projectId, keyword, status, includeArchived, page, and pageSize.

Input schema:
```json
{"properties":{"page":{"minimum":1,"type":"integer"},"pageSize":{"maximum":100,"minimum":1,"type":"integer"},"keyword":{"type":"string"},"projectId":{"type":"string"},"includeArchived":{"type":"boolean"},"status":{"type":"string"}},"type":"object","required":["projectId"],"additionalProperties":false}
```

## metersphere.test_plan.update

Scope: PLAN_WRITE

Patch plan name, description, tags, schedule or execution configuration. Omitted fields are preserved. Requires updateTime from test_plan.get; archived or executing plans are rejected.

Input schema:
```json
{"properties":{"expectedUpdateTime":{"type":"integer"},"projectId":{"type":"string"},"patch":{"properties":{"automaticStatusUpdate":{"type":"boolean"},"plannedEndTime":{"minimum":0,"type":"integer"},"repeatCase":{"type":"boolean"},"plannedStartTime":{"minimum":0,"type":"integer"},"description":{"type":"string"},"name":{"type":"string","maxLength":255,"minLength":1},"passThreshold":{"maximum":100,"minimum":0,"type":"number"},"tags":{"items":{"type":"string"},"type":"array"}},"type":"object","required":[],"additionalProperties":false},"testPlanId":{"type":"string"},"requestId":{"type":"string"}},"type":"object","required":["projectId","testPlanId","expectedUpdateTime","patch","requestId"],"additionalProperties":false}
```

## metersphere.writeback.status.get

Scope: TASK_READ

Get writeback and artifact reconciliation status.

Input schema:
```json
{"properties":{"taskId":{"type":"string"}},"type":"object","required":["taskId"],"additionalProperties":false}
```


## metersphere.bug.export.download

Repository addition; runtime verification pending. Invoke only if live tools/list exposes it. Required scope BUG_READ plus current user export permission. Parameters: projectId, fileId, optional offset (0..5242880), length (1..65536; default 32768). Response: fileId, contentType, offset, nextOffset, eof, sizeBytes, sha256, base64.
