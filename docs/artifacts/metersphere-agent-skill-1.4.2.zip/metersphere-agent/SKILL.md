---
name: metersphere-agent
description: Search and maintain MeterSphere cases, plans, reviews and bugs, and submit personal execution evidence through remote MCP.
---
# MeterSphere Agent

Use this skill when the user asks you to search, create, update, or submit MeterSphere test cases, test execution results, test plans, reviews, or bugs through the MeterSphere remote MCP endpoint.

The skill never contains a real token. Ask the user to create a personal Agent Token in MeterSphere and configure the client with `Authorization: Bearer ${METERSPHERE_AGENT_TOKEN}` or `X-API-Key: ${METERSPHERE_AGENT_TOKEN}`.

Built-in platform addresses:

- Test: `https://msp.ebcone.net`
- Production: `https://msp.ebcone.cn`

Default MCP endpoints:

- Test: `https://msp.ebcone.net/api/mcp`
- Production: `https://msp.ebcone.cn/api/mcp`

Only ask the user for a base URL when they are using a non-standard private deployment.
Transport: Streamable HTTP

Search results with contentError must not be executed. CASE_BODY_INVALID means damaged historical content; CASE_CONTENT_READ_LIMIT means narrow the query and retry. Such rows have no usable steps; inspect top-level warnings instead of assuming zero steps.
Personal case execution (no task or lease): grant FUNCTIONAL_READ, FUNCTIONAL_SUBMIT and CASE_ATTACHMENT.
Contract is optional. One PNG/JPEG image per case execution is sufficient. Do not require client contentHash/policyHash or per-step screenshots.
Upload a case PNG/JPEG with metersphere.functional.execution.evidence.upload (base64, at most 5 MiB) or import_url. Put evidenceIds at submit's top level; steps do not require images.
Submit with metersphere.functional.execution.submit. Cover every original position at least once; extra and repeated positions are allowed and retained. ACCEPTED/PUBLISHED means structure accepted and declared results saved, not independent execution verification. Historical NEEDS_REVIEW submissions remain unchanged.
Report actual observations and SUCCESS or ERROR. No comparison with expected text or content reviewer is used. Any ERROR, including extra or repeated records, makes the case ERROR. Permissions, content/policy versions and evidence rules still apply.
Use metersphere.functional.execution.get to inspect accepted step facts and evidence mapping. Reuse requestId only for identical retries.
For imports, use functional.import.precheck, inspect its report, then import.commit and import.get. Stop preserves successful writes; retry does not duplicate them. Requires explicit CASE_IMPORT_V2.
For deletion, use functional.case.delete_preview and let the user decide at confirmationPath before continuing the same previewId. Never forge user confirmation. CASE_DELETE_V2 and CASE_RESTORE_V2 are explicit permissions, not implied by legacy wildcard scopes.
Archive ended runs with functional.archive.prepare/get/retry. Archival failure never changes the execution verdict. Only submit actual reusable business data through archive.data with sourceObjectId, reuseConditions and cleanupStatus. Requires ARTIFACT_WRITE and current project permissions; no data means no empty dataset.
