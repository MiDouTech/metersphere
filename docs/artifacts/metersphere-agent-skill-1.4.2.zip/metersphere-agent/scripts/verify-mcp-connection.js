const platforms = {
  test: 'https://msp.ebcone.net',
  production: 'https://msp.ebcone.cn',
  prod: 'https://msp.ebcone.cn',
};
const env = (process.env.METERSPHERE_ENV || 'test').toLowerCase();
const baseUrl = process.env.METERSPHERE_BASE_URL || platforms[env];
const token = process.env.METERSPHERE_AGENT_TOKEN;
if (!baseUrl || !token) {
  throw new Error('Set METERSPHERE_AGENT_TOKEN first. Set METERSPHERE_ENV=production or METERSPHERE_BASE_URL only when needed.');
}
const res = await fetch(`${baseUrl.replace(/\/$/, '')}/api/mcp`, {
  method: 'POST',
  headers: {
    'content-type': 'application/json',
    authorization: `Bearer ${token}`,
  },
  body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'ping' }),
});
console.log(res.status, await res.text());
