# MeterSphere Agent Skill Package

1. In MeterSphere, open Personal Center > Agent Configuration.
2. Create a personal Agent Token. The plaintext token is displayed only once.
3. Configure your AI client with one of the built-in remote MCP endpoints:
   - Test: `https://msp.ebcone.net/api/mcp`
   - Production: `https://msp.ebcone.cn/api/mcp`
4. Provide the token through an environment variable or secret store. Do not commit tokens.

If you use a private deployment, set `METERSPHERE_BASE_URL` to that deployment URL and call `${METERSPHERE_BASE_URL}/api/mcp`.
