<template>
  <div class="p-4">
    <MsCard auto-width :min-width="0" hide-footer>
      <template #headerLeft>
        <a-page-header title="资产用例详情" subtitle="此用例属于测试资产，无业务项目执行上下文" @back="goBack" />
      </template>
      <template #headerRight>
        <a-space
          ><a-button @click="goBack">返回</a-button
          ><a-button
            v-if="canUpdate && !deleted"
            type="primary"
            :disabled="loading || !ready"
            :loading="saving"
            @click="save"
            >保存</a-button
          ></a-space
        >
      </template>
      <a-spin :loading="loading" class="block">
        <a-alert v-if="loadError" type="error" class="mb-4">读取用例失败，请刷新页面后重试。</a-alert>
        <a-alert v-if="deleted" class="mb-4" type="warning"
          >该资产用例已被删除，仅保留历史查看；不能编辑或再次导入。</a-alert
        >
        <a-form :model="form" layout="vertical" class="mx-auto max-w-[900px]">
          <a-form-item v-if="sourceBindings.length" label="来源绑定：本次修改方式" required>
            <a-radio-group v-model="sourceEditMode"
              ><a-radio value="WRITE_BACK">回写源用例</a-radio
              ><a-radio value="DETACH">脱离来源，成为独立资产</a-radio></a-radio-group
            >
          </a-form-item>
          <a-form-item v-if="sourceBindings.length && sourceEditMode === 'WRITE_BACK'" label="源用例" required>
            <a-select v-model="sourceCaseId"
              ><a-option v-for="binding in sourceBindings" :key="binding.caseId" :value="binding.caseId"
                >{{ binding.projectId }} / {{ binding.caseId }}</a-option
              ></a-select
            >
          </a-form-item>
          <a-alert v-if="sourceBindings.length" class="mb-4"
            >回写会校验源修改权限与版本；脱离后保留原引用历史。附件请在源用例维护，或先保存脱离来源再上传。</a-alert
          >
          <a-form-item label="用例 ID"><a-input :model-value="caseId" disabled /></a-form-item>
          <a-form-item label="用例名称" required
            ><a-input v-model="form.name" :disabled="deleted || !canUpdate"
          /></a-form-item>
          <a-form-item label="标签"
            ><a-input-tag v-model="form.tags" :disabled="deleted || !canUpdate" allow-clear
          /></a-form-item>
          <a-form-item label="编辑模式"
            ><a-radio-group v-model="form.caseEditType" :disabled="deleted || !canUpdate"
              ><a-radio value="STEP">步骤</a-radio><a-radio value="TEXT">文本</a-radio></a-radio-group
            ></a-form-item
          >
          <a-form-item label="前置条件"
            ><a-textarea
              v-model="form.prerequisite"
              :disabled="deleted || !canUpdate"
              :auto-size="{ minRows: 2, maxRows: 6 }"
          /></a-form-item>
          <a-form-item :label="form.caseEditType === 'STEP' ? '用例步骤（JSON/文本）' : '用例描述'"
            ><a-textarea v-model="form.body" :disabled="deleted || !canUpdate" :auto-size="{ minRows: 8, maxRows: 20 }"
          /></a-form-item>
          <a-form-item label="预期结果"
            ><a-textarea
              v-model="form.expectedResult"
              :disabled="deleted || !canUpdate"
              :auto-size="{ minRows: 3, maxRows: 10 }"
          /></a-form-item>
          <a-form-item label="备注"
            ><a-textarea v-model="form.description" :disabled="deleted || !canUpdate"
          /></a-form-item>
          <a-divider>自定义字段</a-divider>
          <a-form-item v-for="field in form.customFields" :key="field.fieldId" :label="field.name || field.fieldId">
            <a-input v-model="field.value" :disabled="deleted || !canUpdate" />
          </a-form-item>
          <a-divider>附件</a-divider>
          <div class="mb-3 flex items-center gap-2">
            <a-button
              v-if="canUpdate && !deleted"
              :disabled="sourceBindings.length > 0 || loading || !ready"
              @click="attachmentInput?.click()"
              >上传附件</a-button
            >
            <input ref="attachmentInput" class="hidden" type="file" multiple @change="uploadAttachments" />
          </div>
          <a-list :data="attachments" bordered>
            <template #item="{ item }">
              <a-list-item>
                <a-link @click="downloadAttachment(item)">{{ item.fileName }}</a-link>
                <template #actions
                  ><a-link
                    v-if="canUpdate && !deleted"
                    :disabled="sourceBindings.length > 0 || loading || !ready"
                    status="danger"
                    @click="removeAttachment(item)"
                    >删除</a-link
                  ></template
                >
              </a-list-item>
            </template>
          </a-list>
        </a-form>
      </a-spin>
    </MsCard>
  </div>
</template>

<script setup lang="ts">
  import { computed, onBeforeUnmount, onMounted, reactive, ref, watch } from 'vue';
  import { useRoute, useRouter } from 'vue-router';
  import { Message } from '@arco-design/web-vue';

  import MsCard from '@/components/pure/ms-card/index.vue';

  import {
    deleteCaseAssetAttachment,
    downloadCaseAssetAttachment,
    getCaseAssetDetail,
    updateCaseAsset,
    uploadCaseAssetAttachment,
  } from '@/api/modules/case-management/featureCase';
  import { hasAnyPermission } from '@/utils/permission';

  import { TestAssetRouteEnum } from '@/enums/routeEnum';

  const route = useRoute();
  const router = useRouter();
  const catalogId = computed(() => String(route.params.catalogId));
  const caseId = computed(() => String(route.params.caseId));
  const ready = ref(false);
  const loadError = ref(false);
  let revision = 0;
  const context = () => ({ catalogId: catalogId.value, caseId: caseId.value, revision });
  const current = (target: ReturnType<typeof context>) =>
    target.revision === revision && target.caseId === caseId.value && target.catalogId === catalogId.value;
  const loading = ref(false);
  const saving = ref(false);
  const sourceBindings = ref<{ caseId: string; projectId: string; updateTime: number }[]>([]);
  const sourceEditMode = ref<'WRITE_BACK' | 'DETACH'>();
  const sourceCaseId = ref('');
  const expectedUpdateTime = ref<number>();
  const canUpdate = hasAnyPermission(['CASE_ASSET:READ+UPDATE']);
  const deleted = ref(false);
  const attachmentInput = ref<HTMLInputElement>();
  const attachments = ref<any[]>([]);
  const form = reactive({
    name: '',
    tags: [] as string[],
    caseEditType: 'STEP' as 'STEP' | 'TEXT',
    prerequisite: '',
    body: '',
    expectedResult: '',
    description: '',
    customFields: [] as Array<{ fieldId: string; name?: string; value?: string }>,
  });
  async function load() {
    const target = context();
    ready.value = false;
    loadError.value = false;
    loading.value = true;
    try {
      const detail: any = await getCaseAssetDetail(target.catalogId, target.caseId);
      if (!current(target)) return;
      form.name = detail.name || '';
      sourceBindings.value = detail.sourceBindings || [];
      sourceEditMode.value = undefined;
      sourceCaseId.value = sourceBindings.value.length === 1 ? sourceBindings.value[0].caseId : '';
      expectedUpdateTime.value = detail.updateTime;
      form.caseEditType = detail.caseEditType || 'STEP';
      form.prerequisite = detail.prerequisite || '';
      form.body = form.caseEditType === 'STEP' ? detail.steps || '' : detail.textDescription || '';
      form.expectedResult = detail.expectedResult || '';
      form.description = detail.description || '';
      form.tags = detail.tags || [];
      form.customFields = (detail.customFields || []).map((field: any) => ({
        fieldId: field.fieldId || field.id,
        name: field.fieldName || field.name,
        value: String(field.value ?? field.defaultValue ?? ''),
      }));
      attachments.value = detail.attachments || [];
      deleted.value = Boolean(detail.deleted);
      ready.value = true;
    } catch {
      if (current(target)) loadError.value = true;
    } finally {
      if (current(target)) loading.value = false;
    }
  }
  async function save() {
    if (!ready.value || loading.value || saving.value) return;
    const target = context();
    if (
      sourceBindings.value.length &&
      (!sourceEditMode.value || (sourceEditMode.value === 'WRITE_BACK' && !sourceCaseId.value))
    ) {
      Message.warning('请选择回写源用例或脱离来源，并确认源用例');
      return;
    }
    if (!form.name.trim()) {
      Message.warning('请输入用例名称');
      return;
    }
    saving.value = true;
    try {
      await updateCaseAsset({
        id: target.caseId,
        catalogId: target.catalogId,
        sourceEditMode: sourceEditMode.value,
        sourceCaseId: sourceCaseId.value,
        expectedUpdateTime: expectedUpdateTime.value,
        expectedSourceUpdateTime: sourceBindings.value.find((binding) => binding.caseId === sourceCaseId.value)
          ?.updateTime,
        name: form.name.trim(),
        tags: form.tags,
        customFields: form.customFields.map(({ fieldId, value }) => ({ fieldId, value })),
        attachments: attachments.value,
        caseEditType: form.caseEditType,
        prerequisite: form.prerequisite,
        steps: form.caseEditType === 'STEP' ? form.body : '',
        textDescription: form.caseEditType === 'TEXT' ? form.body : '',
        expectedResult: form.expectedResult,
        description: form.description,
      });
      if (!current(target)) return;
      Message.success(sourceEditMode.value === 'WRITE_BACK' ? '源用例已保存，资产同步正在处理' : '保存成功');
      await load();
    } finally {
      if (current(target)) saving.value = false;
    }
  }
  async function refreshAttachments(target = context()) {
    const detail = await getCaseAssetDetail(target.catalogId, target.caseId);
    if (!current(target)) return;
    attachments.value = detail.attachments || [];
  }
  async function uploadAttachments(event: Event) {
    if (!ready.value || loading.value) return;
    const target = context();
    const input = event.target as HTMLInputElement;
    const files = Array.from(input.files || []);
    try {
      const results = await Promise.allSettled(
        files.map((file) => uploadCaseAssetAttachment(target.catalogId, target.caseId, file))
      );
      if (!current(target)) return;
      await refreshAttachments(target);
      const failed = results.find((result) => result.status === 'rejected');
      if (failed?.status === 'rejected') throw failed.reason;
    } finally {
      input.value = '';
    }
  }
  async function removeAttachment(item: any) {
    if (!ready.value || loading.value) return;
    const target = context();
    await deleteCaseAssetAttachment(target.catalogId, target.caseId, item.id, item.local !== false);
    if (current(target)) await refreshAttachments(target);
  }
  async function downloadAttachment(item: any) {
    const target = context();
    const blob = await downloadCaseAssetAttachment(target.catalogId, target.caseId, item.id, item.local !== false);
    if (!current(target)) return;
    const url = URL.createObjectURL(blob as Blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = item.fileName || 'attachment';
    link.click();
    URL.revokeObjectURL(url);
  }
  function goBack() {
    router.push({
      name:
        route.query.directory === 'system'
          ? TestAssetRouteEnum.TEST_ASSET_CASES_SYSTEM
          : TestAssetRouteEnum.TEST_ASSET_CASES_PROJECT,
      query: route.query,
    });
  }
  onMounted(load);
  watch(
    [catalogId, caseId],
    () => {
      revision++;
      ready.value = false;
      saving.value = false;
      Object.assign(form, {
        name: '',
        tags: [],
        caseEditType: 'STEP',
        prerequisite: '',
        body: '',
        expectedResult: '',
        description: '',
        customFields: [],
      });
      attachments.value = [];
      sourceBindings.value = [];
      sourceEditMode.value = undefined;
      sourceCaseId.value = '';
      expectedUpdateTime.value = undefined;
      deleted.value = false;
      if (!route.params.catalogId || !route.params.caseId) {
        loading.value = false;
        return;
      }
      load();
    },
    { flush: 'sync' }
  );
  onBeforeUnmount(() => {
    revision++;
  });
</script>
